create trigger usr_info_AFTER_INSERT
  after INSERT
  on usr_info
  for each row
  BEGIN
	DECLARE id integer;
    SET id:= (select usr_id from usr_info order by usr_id desc limit 1);
    INSERT INTO usr_log(usr_id) value(id); 
END;

